// tästä alas on Muhammed Melih Özturk koodi


package fi.metropolia.megaforce;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Button;

public class Ajastin extends AppCompatActivity implements SensorEventListener {
    private TextView textViewStepCounter, textViewStepDetector;
    private SensorManager sensorManager;
    private Sensor mStepCounter;
    private boolean isCounterSensorPresent;
    int stepCountStartup = -1;
    int stepCount = 0;

    TextView nimi, ika, pituus;

    Button button;






    private ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    // Permission is granted. Continue the action or workflow in your
                    // app.
                } else {
                    // Explain to the user that the feature is unavailable because the
                    // features requires a permission that the user has denied. At the
                    // same time, respect the user's decision. Don't link to system
                    // settings in an effort to convince the user to change their
                    // decision.
                }
            });


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Henkilo uusHenkilo = Henkilo.getUserInstance();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajastin);


        nimi = findViewById(R.id.nimiText);
        ika = findViewById(R.id.ikaText);
        pituus = findViewById(R.id.pituusText);

        button = findViewById(R.id.button);

        nimi.setText(uusHenkilo.getNimi());
        ika.setText(Integer.toString(uusHenkilo.getIka()));
        pituus.setText(Integer.toString(uusHenkilo.getPituus()));



        button.setOnClickListener(view -> {


            switchActivities();
        });


        Intent intent = getIntent();
        String getNimi = intent.getStringExtra("Nimi");
        String getIka = intent.getStringExtra("Ika");
        String getPituus = intent.getStringExtra("Pituus");
        //Set Text
        nimi.setText(getNimi);
        ika.setText(getIka);
        pituus.setText(getPituus);


        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        textViewStepCounter = findViewById(R.id.textViewStepCounter);
        textViewStepDetector = findViewById(R.id.textViewStepDetector);

        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_DENIED) {
            requestPermissionLauncher.launch(
                    Manifest.permission.ACTIVITY_RECOGNITION);
        }

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);


        if (sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null) {

            mStepCounter = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
            isCounterSensorPresent = true;

        } else {
            textViewStepCounter.setText("Counter Sensor is not Present");
            isCounterSensorPresent = false;

        }


    }


    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor == mStepCounter) {
            if (stepCountStartup == -1) {
                stepCountStartup = (int) sensorEvent.values[0];
            }
            stepCount = (int) sensorEvent.values[0] - stepCountStartup;
            textViewStepCounter.setText(String.valueOf(stepCount));
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    protected void onResume() {
        super.onResume();
        if (sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null) {
            sensorManager.registerListener(this, mStepCounter, SensorManager.SENSOR_DELAY_FASTEST);
        }

    }

    protected void onPause() {
        super.onPause();
        if (sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null) {
            sensorManager.unregisterListener(this, mStepCounter);
        }

    }
    private void switchActivities(){

        Intent switchActivityIntent = new Intent(this, profiili.class);
        startActivity(switchActivityIntent);
    }
}