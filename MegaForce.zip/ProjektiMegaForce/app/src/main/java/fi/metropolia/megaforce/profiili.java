package fi.metropolia.megaforce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class profiili extends AppCompatActivity {

    Button button;

    TextView nimi, ika, pituus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Henkilo uusHenkilo = Henkilo.getUserInstance();



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profiili);



        nimi = findViewById(R.id.nimiText);
        ika = findViewById(R.id.ikaText);
        pituus = findViewById(R.id.pituusText);

        button = findViewById(R.id.button);

        nimi.setText(uusHenkilo.getNimi());
        ika.setText(Integer.toString(uusHenkilo.getIka()));
        pituus.setText(Integer.toString(uusHenkilo.getPituus()));



        Button back = findViewById(R.id.button2);


        back.setOnClickListener(view -> {

            switchActivities();

        });


    }

    private void switchActivities(){

        Intent switchActivityIntent = new Intent(this, Ajastin.class);
        startActivity(switchActivityIntent);
    }
}