// tästä alas on Muhammed Melih Özturk koodi

package fi.metropolia.megaforce;

public class Henkilo {
    private static Henkilo userInstance = null;
    String nimi;
    int ika;
    int pituus;


    public static void setUserInstance(Henkilo ourInstance) {
        Henkilo.userInstance = ourInstance;
    }
    public static Henkilo getUserInstance() {
        return userInstance;
    }

    public Henkilo(String nimi, int ika, int pituus ) {

        this.nimi = nimi;
        this.ika = ika;
        this.pituus = pituus;

    }


    public String getNimi() {
        return nimi;
    }

    public int getIka() {
        return ika;
    }

    public int getPituus() {
        return pituus;
    }



}

