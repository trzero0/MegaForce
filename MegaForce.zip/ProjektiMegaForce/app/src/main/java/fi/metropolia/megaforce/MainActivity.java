// tästä alas on Muhammed Melih Özturk koodi


package fi.metropolia.megaforce;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
    private EditText nimi, ika, pituus;
    private String username;
    private int userAge, userLength;





    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button AjastinAct = (Button) findViewById(R.id.buttonToAjastin);

        nimi = findViewById(R.id.editTextPersonName);
        ika = findViewById(R.id.editTextPersonAge);
        pituus = findViewById(R.id.editTextPersonHeight);








        SharedPreferences preferences = getSharedPreferences("PREFERENCE", MODE_PRIVATE);
        String FirstTime = preferences.getString("FirstTimeInstall", "Yes");




        AjastinAct.setOnClickListener(view -> {

            username = nimi.getText().toString();
            userAge = Integer.parseInt(ika.getText().toString());
            userLength = Integer.parseInt(pituus.getText().toString());

            Henkilo uushenkilo = new Henkilo(username, userAge, userLength);
            Henkilo.setUserInstance(uushenkilo);


            if (FirstTime.equals("Yes")){

                switchActivities();

            }else{
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("FirstTimeInstall", "Yes");
                editor.apply();
            }


        });
    }









    private void switchActivities(){

        Intent switchActivityIntent = new Intent(this, Ajastin.class);
        startActivity(switchActivityIntent);
    }


}
